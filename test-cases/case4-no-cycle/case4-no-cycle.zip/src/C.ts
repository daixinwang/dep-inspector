// 测试用例 4：无循环
// C.ts 无导入（叶子节点）
export function functionC() {
  console.log('Function C');
  // 这是一个叶子节点，不依赖任何其他模块
  return 'Hello from C';
}
